import { useCallback, useEffect, useMemo, useState } from "react";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState("Medium");
  const [filter, setFilter] = useState("All");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const loadTasks = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch(`${API_URL}/tasks`);
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Could not load tasks.");
      setTasks(data);
    } catch (err) {
      setError(`${err.message} Make sure the backend and MongoDB are running.`);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadTasks(); }, [loadTasks]);

  const addTask = async (event) => {
    event.preventDefault();
    if (!title.trim()) return;
    setSaving(true);
    setError("");
    try {
      const response = await fetch(`${API_URL}/tasks`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: title.trim(), description: description.trim(), priority })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Could not create task.");
      setTasks((current) => [data, ...current]);
      setTitle("");
      setDescription("");
      setPriority("Medium");
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const toggleTask = async (task) => {
    setError("");
    try {
      const response = await fetch(`${API_URL}/tasks/${task._id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ completed: !task.completed })
      });
      const updated = await response.json();
      if (!response.ok) throw new Error(updated.message || "Could not update task.");
      setTasks((current) => current.map((item) => item._id === updated._id ? updated : item));
    } catch (err) {
      setError(err.message);
    }
  };

  const deleteTask = async (id) => {
    if (!window.confirm("Delete this task?")) return;
    setError("");
    try {
      const response = await fetch(`${API_URL}/tasks/${id}`, { method: "DELETE" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Could not delete task.");
      setTasks((current) => current.filter((task) => task._id !== id));
    } catch (err) {
      setError(err.message);
    }
  };

  const visibleTasks = useMemo(() => tasks.filter((task) => {
    if (filter === "Active") return !task.completed;
    if (filter === "Completed") return task.completed;
    return true;
  }), [tasks, filter]);

  const completedCount = tasks.filter((task) => task.completed).length;

  return (
    <main className="app-shell">
      <header className="topbar">
        <a className="brand" href="#" aria-label="FLEXI home">
          <span className="brand-mark">F</span><span>FLEXI</span>
        </a>
        <span className="topbar-note"><span className="status-dot" /> Your workspace</span>
      </header>

      <section className="hero">
        <div>
          <p className="eyebrow">PLAN SMARTER · DO MORE</p>
          <h1>Make room for<br /><span>what matters.</span></h1>
          <p className="hero-copy">One flexible space to organize your tasks, focus on priorities, and keep your momentum.</p>
        </div>
        <div className="hero-card" aria-label="Task completion summary">
          <div className="hero-card-top"><span>YOUR PROGRESS</span><span className="sparkle">✦</span></div>
          <div className="progress-number">{tasks.length ? Math.round(completedCount / tasks.length * 100) : 0}<small>%</small></div>
          <div className="progress-track"><span style={{ width: `${tasks.length ? completedCount / tasks.length * 100 : 0}%` }} /></div>
          <p>{completedCount} of {tasks.length} tasks completed</p>
        </div>
      </section>

      <section className="workspace">
        <div className="section-heading">
          <div><p className="eyebrow">YOUR WORKSPACE</p><h2>Task board <span className="count-pill">{tasks.length}</span></h2></div>
          <button className="refresh-button" type="button" onClick={loadTasks}>↻ Refresh</button>
        </div>

        <div className="content-grid">
          <form className="create-card" onSubmit={addTask}>
            <div className="card-heading"><span className="plus-icon">＋</span><div><h3>Create a task</h3><p>Start with one small step.</p></div></div>
            <label htmlFor="task-title">Task name</label>
            <input id="task-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Prepare project presentation" maxLength={120} required />
            <label htmlFor="task-description">Description <span className="optional">OPTIONAL</span></label>
            <textarea id="task-description" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Add a few details..." rows={3} maxLength={1000} />
            <label htmlFor="task-priority">Priority</label>
            <select id="task-priority" value={priority} onChange={(e) => setPriority(e.target.value)}>
              <option>Low</option><option>Medium</option><option>High</option>
            </select>
            <button className="primary-button" type="submit" disabled={saving}>{saving ? "Saving..." : "＋ Add task"}</button>
          </form>

          <div className="task-panel">
            <div className="filter-row" role="tablist" aria-label="Filter tasks">
              {["All", "Active", "Completed"].map((name) => (
                <button key={name} type="button" role="tab" aria-selected={filter === name} className={`filter-button ${filter === name ? "selected" : ""}`} onClick={() => setFilter(name)}>{name}</button>
              ))}
            </div>

            {error && <div className="error-banner" role="alert">{error}</div>}
            {loading ? <div className="empty-state"><div className="empty-icon">↻</div><h3>Loading tasks…</h3><p>Connecting to your workspace.</p></div> :
              visibleTasks.length === 0 ? (
                <div className="empty-state"><div className="empty-icon">✦</div><h3>{filter === "Completed" ? "Nothing completed yet" : filter === "Active" ? "All caught up!" : "Your board is clear"}</h3><p>{filter === "Completed" ? "Completed tasks will show up here." : "Add a task to turn your plans into progress."}</p></div>
              ) : (
                <div className="task-list">
                  {visibleTasks.map((task) => (
                    <article className={`task-item ${task.completed ? "is-complete" : ""}`} key={task._id}>
                      <button className={`check-button ${task.completed ? "checked" : ""}`} type="button" aria-label={task.completed ? "Mark as active" : "Mark as completed"} onClick={() => toggleTask(task)}>{task.completed ? "✓" : ""}</button>
                      <div className="task-info">
                        <h3>{task.title}</h3>
                        {task.description && <p>{task.description}</p>}
                        <div className="task-meta"><span className={`priority priority-${task.priority.toLowerCase()}`}>{task.priority} priority</span><span>{new Date(task.createdAt).toLocaleDateString()}</span></div>
                      </div>
                      <button className="delete-button" type="button" aria-label={`Delete ${task.title}`} onClick={() => deleteTask(task._id)}>×</button>
                    </article>
                  ))}
                </div>
              )
            }
            <div className="panel-footer"><span>Stored in MongoDB</span><span>Made for your momentum ✦</span></div>
          </div>
        </div>
      </section>
      <footer className="footer"><span>FLEXI © {new Date().getFullYear()}</span><span>Small steps. Real progress.</span></footer>
    </main>
  );
}
