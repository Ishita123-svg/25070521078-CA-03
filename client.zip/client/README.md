# FLEXI client (frontend)

React + Vite frontend.

## Run locally
1. In this folder run `npm install`.
2. Run `npm run dev`.
3. Open the local URL printed by Vite (usually `http://localhost:5173`).

The frontend defaults to `http://localhost:5000/api`. For deployment, create a `.env` file before building and set `VITE_API_URL` to your deployed backend API base URL ending in `/api`, for example `VITE_API_URL=https://your-api.example.com/api`.
