# FLEXI server (backend)

## Run locally
1. Install Node.js 18 or newer and run MongoDB locally, or use MongoDB Atlas.
2. Copy `.env.example` to `.env` and set `MONGODB_URI`.
3. In this folder run `npm install`, then `npm run dev`.
4. Health endpoint: `http://localhost:5000/api/health`.

## API
- `GET /api/tasks` — list tasks
- `POST /api/tasks` — create task (`title`, optional `description`, optional `priority`)
- `PATCH /api/tasks/:id` — update task fields
- `DELETE /api/tasks/:id` — delete task
- `GET /api/health` — API/database status

For online deployment, deploy this server to a Node.js hosting service and use a hosted MongoDB database (such as MongoDB Atlas). Set `MONGODB_URI`, `CLIENT_ORIGIN`, and `PORT` in the hosting environment. Set the client's `VITE_API_URL` to the deployed API base URL ending in `/api` before building the frontend.
